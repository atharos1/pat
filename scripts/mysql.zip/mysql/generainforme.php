<?php
	require_once('../VerificarLogin.php');
	
	include('../../vendors/fpdf/fpdf.php');
	include('../../vendors/fpdi/fpdi.php'); 

	$ProtocoloID = $_GET["Protocolo"];

	include("conexion.php");

	if($ProtocoloID >= 85759) { //Protocolo nuevo
		$strSQL = "Select DATE_FORMAT(pro.FechaOrden,'%d/%m/%Y') as 'Fecha',
		CONCAT(UPPER(m.Apellido), ', ', m.Nombre) as 'Medico', 
		CONCAT(UPPER(p.Apellido), ', ', p.Nombre) as 'AyN', 
		pro.Informe1 
		FROM Protocolos pro 
		LEFT Join Pacientes p On p.ID = pro.PacienteID 
		LEFT Join Medicos m On m.ID = pro.MedicoID 
		WHERE pro.ID = $ProtocoloID";
	} else { //Protocolo viejo
		$strSQL = "Select DATE_FORMAT(pro.FechaBiopsia,'%d/%m/%Y') as 'Fecha', CONCAT(m.Apellido, ', ', m.Nombre) as 'Medico', CONCAT(p.Apellido, ', ', p.Nombre) as 'AyN', pro.InformePrincipal as 'Informe1' 
			FROM v_Protocolos pro Inner Join v_Pacientes p On p.ID = pro.IDPaciente Inner Join v_Medicos m On m.ID = pro.IDMedico WHERE pro.IDProtocolo = $ProtocoloID";
	}

	$query = mysqli_query($conn, $strSQL);
	if (!$query) {
		echo 'MySQL Error: ' . mysqli_error($conn);
		die;
	}
					
	$row = mysqli_fetch_assoc($query);

	$Nombre = $row["AyN"];
	$Medico = $row["Medico"];
	$Informe1 = $row["Informe1"];
	$Fecha = $row["Fecha"];

	// initiate FPDI 
	$pdf =& new FPDI(); 
	// add a page 
	$pdf->AddPage(); 
	// set the sourcefile 
	$pdf->setSourceFile('../../Templates/informe.pdf'); 
	// import page 1 
	$tplIdx = $pdf->importPage(1); 
	// use the imported page as the template 
	$pdf->useTemplate($tplIdx, 0, 0); 

	// now write some text above the imported page 
	$pdf->SetFont('times'); 
	$pdf->SetTextColor(0,0,0); 

	$pdf->SetXY(20, 55); 
	$pdf->Write(0, utf8_decode("Sr. /a: " . $Nombre . ".")); 

	$pdf->SetXY(20, 60); 
	$pdf->Write(0, utf8_decode("Protocolo Nº: " . $ProtocoloID . ".")); 

	$pdf->SetXY(20, 65); 
	$pdf->Write(0, utf8_decode("A indicación del Dr./a: " . $Medico . ".")); 

	$pdf->SetXY(20, 70); 
	$pdf->Write(0, utf8_decode("Fecha: " . $Fecha . ".")); 

	$pdf->SetXY(75, 90); 
	$pdf->SetFont('times', 'B');
	$pdf->Write(0, "INFORME ANATOMOPATOLOGICO"); 

	$pdf->SetFont('times');
	$pdf->SetXY(20, 95); 
	$pdf->MultiCell(0, 5, utf8_decode($Informe1), 0);

	$pdf->SetTitle('Informe (Protocolo #' . $ProtocoloID . ')');
	ob_end_clean();
	$pdf->Output('Protocolo ' . $ProtocoloID . '.pdf', 'I'); 

?>