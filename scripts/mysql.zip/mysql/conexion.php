﻿<?php
// CONEXION BASE DE DATOS MYSQL
		$servername = "localhost";
		$username = "root";
		$password = "ventormenta1";
		$db = "patol";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $db);

		if (mysqli_connect_error()) {
		    die("Error en la conexión con la base de datos: " . 							mysqli_connect_error());
		}

		mysqli_set_charset($conn, "utf8");
		//* CONEXION BASE DE DATOS MYSQL
?>